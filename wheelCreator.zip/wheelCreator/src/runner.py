from myTCL.unknown import *

vp_start_gui()

def runner():
    vp_start_gui()
