from cx_Freeze import setup, Executable
import os, sys
import tkinter
root = tkinter.Tk()

PYTHON_INSTALL_DIR = os.path.dirname(os.path.dirname(os.__file__))
#os.environ['TCL_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tcl8.6')
#os.environ['TK_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tk8.6')

os.environ['TCL_LIBRARY'] = root.tk.exprstring('$tcl_library')
os.environ['TK_LIBRARY'] = root.tk.exprstring('$tk_library')

base=None
if sys.platform == "win32":
    base = "Win32GUI"
#from PyQt5 import uic
#uic.loadUi("pyBOT.ui", self)
#ProgramMenuFolder
#ProgramFilesFolder
#DesktopFolder
#CommonFilesFolder
#CommonAppDataFolder
executables = [
        Executable('unknown.py', base=base, targetName = 'myTCL.exe', shortcutName="myTCL", shortcutDir="DesktopFolder",),
    ]
#includefiles=["img/BeBOT-splash.png", "BeBOT.ico"]
#buildOptions = dict(include_files = [(absolute_path_to_file,'final_filename')])
buildOptions = dict(include_files = [
                                        os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tk86t.dll'),
                                        os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tcl86t.dll'),
                                    ]
                    )



shortcut_table = [
    ("DesktopShortcut",        # Shortcut
     "DesktopFolder",          # Directory_
     "pyBOT",                  # Name
     "TARGETDIR",              # Component_
     "[TARGETDIR]playlist.exe",# Target
     None,                     # Arguments
     None,                     # Description
     None,                     # Hotkey
     None,                     # Icon
     None,                     # IconIndex
     None,                     # ShowCmd
     'TARGETDIR'               # WkDir
     )
    ]

# Now create the table dictionary
msi_data = {"Shortcut": shortcut_table}

# Change some default MSI options and specify the use of the above defined tables
bdist_msi_options = {'data': msi_data}


#options = {
        #"bdist_msi": bdist_msi_options,
    #}

setup(  name = "pyBOT",
        version = "1.0",
        description = "pyBOT -Automated Web Page Navigator",
        options = dict(build_exe = buildOptions),
        executables = executables
        ,)
#python setup.py bdist_msi
#python setup.py build
